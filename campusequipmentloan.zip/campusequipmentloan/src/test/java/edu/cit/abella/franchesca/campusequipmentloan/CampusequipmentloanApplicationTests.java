package edu.cit.abella.franchesca.campusequipmentloan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusequipmentloanApplicationTests {

	@Test
	void contextLoads() {
	}

}
