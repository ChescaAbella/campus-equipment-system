package edu.cit.abella.franchesca.campusequipmentloan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusequipmentloanApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusequipmentloanApplication.class, args);
	}

}
